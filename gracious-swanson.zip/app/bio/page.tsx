"use client";
import { useState } from "react";

export default function BioPage() {
  const [name, setName] = useState("");
  const [result, setResult] = useState("");
  const [loading, setLoading] = useState(false);

  const generateBio = () => {
    if (!name) {
      setResult("Please write your name or niche first.");
      return;
    }

    setLoading(true);

    const bios = [
      `🚀 ${name} | Passionate creator sharing value daily.`,
      `✨ ${name} | Building, learning & growing every day.`,
      `🔥 ${name} | Turning ideas into impact.`,
      `💡 ${name} | Content. Creativity. Consistency.`,
      `📈 ${name} | Helping you level up your game.`
    ];

    setTimeout(() => {
      const randomBio =
        bios[Math.floor(Math.random() * bios.length)];
      setResult(randomBio);
      setLoading(false);
    }, 800);
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(result);
  };

  return (
    <main className="min-h-screen flex flex-col items-center justify-center bg-gray-100 px-4">
      <h1 className="text-4xl font-bold mb-6">
        Bio Generator 🧑‍💼
      </h1>

      <input
        type="text"
        value={name}
        onChange={(e) => setName(e.target.value)}
        placeholder="Write your name or niche..."
        className="w-full max-w-md p-4 rounded-lg border focus:outline-none focus:ring-2 focus:ring-black"
      />

      <button
        onClick={generateBio}
        className="mt-6 px-6 py-3 bg-black text-white rounded-lg hover:bg-gray-800 transition"
      >
        {loading ? "Generating..." : "Generate Bio"}
      </button>

      {result && (
        <div className="mt-6 p-4 bg-white rounded-lg shadow w-full max-w-md">
          <p className="mb-4">{result}</p>
          <button
            onClick={copyToClipboard}
            className="px-4 py-2 bg-gray-200 rounded hover:bg-gray-300 transition"
          >
            Copy
          </button>
        </div>
      )}
    </main>
  );
}