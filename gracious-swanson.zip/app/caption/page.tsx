"use client";
import { useState } from "react";

export default function CaptionPage() {
  const [topic, setTopic] = useState("");
  const [result, setResult] = useState("");
  const [loading, setLoading] = useState(false);

  const generateCaption = () => {
    if (!topic) {
      setResult("Please write a topic first.");
      return;
    }

    setLoading(true);

    const captions = [
      `🔥 ${topic} is changing the game right now! Don’t miss out!`,
      `🚀 If you're into ${topic}, this is for you!`,
      `✨ Discover why ${topic} is trending everywhere.`,
      `💡 ${topic} might be exactly what you need today.`,
      `📈 Everyone is talking about ${topic} – here’s why!`,
    ];

    setTimeout(() => {
      const randomCaption =
        captions[Math.floor(Math.random() * captions.length)];
      setResult(randomCaption + " #socialmedia #viral");
      setLoading(false);
    }, 800);
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(result);
  };

  return (
    <main className="min-h-screen flex flex-col items-center justify-center bg-gray-100 px-4">
      <h1 className="text-4xl font-bold mb-6">Caption Generator ✍️</h1>

      <textarea
        value={topic}
        onChange={(e) => setTopic(e.target.value)}
        placeholder="Write your topic here..."
        className="w-full max-w-md h-40 p-4 rounded-lg border focus:outline-none focus:ring-2 focus:ring-black"
      />

      <button
        onClick={generateCaption}
        className="mt-6 px-6 py-3 bg-black text-white rounded-lg hover:bg-gray-800 transition"
      >
        {loading ? "Generating..." : "Generate Caption"}
      </button>

      {result && (
        <div className="mt-6 p-4 bg-white rounded-lg shadow w-full max-w-md">
          <p className="mb-4">{result}</p>
          <button
            onClick={copyToClipboard}
            className="px-4 py-2 bg-gray-200 rounded hover:bg-gray-300 transition"
          >
            Copy
          </button>
        </div>
      )}
    </main>
  );
}
