"use client";
import { useState } from "react";

export default function HashtagPage() {
  const [topic, setTopic] = useState("");
  const [result, setResult] = useState("");
  const [loading, setLoading] = useState(false);

  const generateHashtags = () => {
    if (!topic) {
      setResult("Please write a topic first.");
      return;
    }

    setLoading(true);

    setTimeout(() => {
      const hashtags = [
        `#${topic.replace(/\s+/g, "")}`,
        `#${topic.replace(/\s+/g, "")}Tips`,
        `#${topic.replace(/\s+/g, "")}Life`,
        `#${topic.replace(/\s+/g, "")}Daily`,
        `#${topic.replace(/\s+/g, "")}Inspo`,
        "#trending",
        "#viral",
        "#contentcreator",
        "#socialmedia",
      ];

      setResult(hashtags.join(" "));
      setLoading(false);
    }, 800);
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(result);
  };

  return (
    <main className="min-h-screen flex flex-col items-center justify-center bg-gray-100 px-4">
      <h1 className="text-4xl font-bold mb-6 text-center">
        Hashtag Generator #
      </h1>

      <textarea
        value={topic}
        onChange={(e) => setTopic(e.target.value)}
        placeholder="Write your topic here..."
        className="w-full max-w-md h-40 p-4 rounded-lg border focus:outline-none focus:ring-2 focus:ring-black"
      />

      <button
        onClick={generateHashtags}
        className="mt-6 px-6 py-3 bg-black text-white rounded-lg hover:bg-gray-800 transition"
      >
        {loading ? "Generating..." : "Generate Hashtags"}
      </button>

      {result && (
        <div className="mt-6 p-4 bg-white rounded-lg shadow w-full max-w-md">
          <p className="mb-4">{result}</p>
          <button
            onClick={copyToClipboard}
            className="px-4 py-2 bg-gray-200 rounded hover:bg-gray-300 transition"
          >
            Copy
          </button>
        </div>
      )}
    </main>
  );
}
