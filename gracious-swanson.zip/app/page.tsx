export default function Home() {
  return (
    <main className="min-h-screen bg-gray-100">
      <div>
        <h1 className="text-5xl font-bold text-center mb-4">Hookify 🚀</h1>
        <p className="text-gray-600 text-lg mt-4">
          Free viral hook generator for TikTok creators. Create scroll-stopping
          hooks in seconds.
        </p>
      </div>

      <div className="bg-white py-20">
        <h2 className="text-3xl font-bold text-center mb-12">
          Free TikTok Creator Tools
        </h2>

        <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto px-6">
          <a
            href="/caption"
            className="block p-6 bg-gray-100 rounded-xl shadow hover:shadow-lg transition hover:scale-105"
          >
            <h4 className="text-xl font-semibold mb-3">Caption Generator</h4>
            <p className="text-gray-600">
              Generate engaging social media captions instantly.
            </p>
          </a>

          <a
            href="/hashtag"
            className="block p-6 bg-gray-100 rounded-xl shadow hover:shadow-lg transition hover:scale-105"
          >
            <h4 className="text-xl font-semibold mb-3">Hashtag Generator</h4>
            <p className="text-gray-600">
              Generate trending hashtags for your content.
            </p>
          </a>

          <a
            href="/bio"
            className="block p-6 bg-gray-100 rounded-xl shadow hover:shadow-lg transition hover:scale-105"
          >
            <h4 className="text-xl font-semibold mb-3">Bio Generator</h4>
            <p className="text-gray-600">
              Create the perfect Instagram or TikTok bio.
            </p>
          </a>
          <a
            href="/viral"
            className="block p-6 bg-gray-100 rounded-xl shadow hover:shadow-lg transition hover:scale-105"
          >
            <h4 className="text-xl font-semibold mb-3">Viral Toolkit 🔥</h4>
            <p className="text-gray-600">
              Generate viral hooks for TikTok & Instagram.
            </p>
          </a>
        </div>
      </div>
      <section className="mt-20 text-center">
        <h2 className="text-3xl font-bold mb-6">Why Hookify?</h2>

        <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto text-gray-600">
          <div>
            <h3 className="font-semibold text-xl mb-2">⚡ Instant Hooks</h3>
            <p>Generate scroll-stopping hooks in seconds.</p>
          </div>

          <div>
            <h3 className="font-semibold text-xl mb-2">🎯 Creator Focused</h3>
            <p>Built for TikTok beginners who want to grow fast.</p>
          </div>

          <div>
            <h3 className="font-semibold text-xl mb-2">🚀 100% Free</h3>
            <p>No signup. No payment. Just pure creativity.</p>
          </div>
        </div>
      </section>
    </main>
  );

