"use client";
import { useState } from "react";

export default function ViralPage() {
  const [niche, setNiche] = useState("");
  const [hooks, setHooks] = useState([]);
  const [loading, setLoading] = useState(false);
  const [ideas, setIdeas] = useState<string[]>([]);

  const generateHooks = () => {
    const generateIdeas = () => {
      if (!niche) {
        setIdeas(["Please write your niche first."]);
        return;
      }

      const ideaTemplates = [
        `3 mistakes people make in ${niche}`,
        `How to grow fast in ${niche}`,
        `My daily routine in ${niche}`,
        `Beginner guide to ${niche}`,
        `Things I wish I knew about ${niche}`,
        `How I made progress in ${niche}`,
        `Secrets nobody tells you about ${niche}`,
      ];

      setIdeas(ideaTemplates);
    };
    if (!niche) {
      setHooks(["Please write your niche first."]);
      return;
    }

    setLoading(true);

    const hookTemplates = [
      `Stop scrolling if you're into ${niche}…`,
      `Nobody talks about this in ${niche}, but…`,
      `If you're struggling with ${niche}, watch this.`,
      `This ${niche} trick changed everything for me.`,
      `I wish I knew this about ${niche} earlier.`,
      `99% of people in ${niche} are doing this wrong.`,
      `Here’s the secret nobody shares about ${niche}.`,
    ];

    setTimeout(() => {
      setHooks(hookTemplates);
      setLoading(false);
    }, 800);
  };

  return (
    <main className="min-h-screen flex flex-col items-center bg-gray-100 px-4 py-16">
      <h1 className="text-4xl font-bold mb-6">Viral Hook Generator 🔥</h1>
      <p className="text-gray-600 mb-8 text-center max-w-md">
        Generate viral hooks and content ideas for TikTok & Instagram creators
        in seconds.
      </p>

      <input
        type="text"
        value={niche}
        onChange={(e) => setNiche(e.target.value)}
        placeholder="Enter your niche (e.g. fitness, business...)"
        className="w-full max-w-md p-4 rounded-lg border focus:outline-none focus:ring-2 focus:ring-black"
      />
      <div className="flex flex-wrap gap-2 mt-4 max-w-md">
        {["Fitness", "Business", "Motivation", "Tech", "Gaming"].map((item) => (
          <button
            key={item}
            onClick={() => setNiche(item)}
            className="px-3 py-1 bg-gray-200 rounded-full hover:bg-black hover:text-white transition"
          >
            {item}
          </button>
        ))}
      </div>

      <button
        onClick={generateHooks}
        className="mt-6 px-6 py-3 bg-black text-white rounded-lg hover:bg-gray-800 transition"
      >
        {loading ? "Generating..." : "Generate Hooks"}
      </button>

      <button onClick={generateHooks} className="...">
        {loading ? "Generating..." : "Generate Hooks"}
      </button>
      {hooks.length > 0 && (
        <div className="mt-10 w-full max-w-md space-y-4">
          {hooks.map((hook, index) => (
            <div
              key={index}
              className="p-4 bg-white rounded-lg shadow flex justify-between items-center"
            >
              <span className="mr-4">{hook}</span>

              <button
                onClick={() => navigator.clipboard.writeText(hook)}
                className="px-3 py-1 bg-black text-white rounded hover:bg-gray-800 transition"
              >
                Copy
              </button>
            </div>
          ))}
        </div>
      )}
    </main>
  );
}
